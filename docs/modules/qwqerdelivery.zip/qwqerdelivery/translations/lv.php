<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{qwqerdelivery}prestashop>qwqerdelivery_a8475a13b5124a9a617913e8ded2890d'] = 'QWQER EXPRESS Piegāde';
$_MODULE['<{qwqerdelivery}prestashop>qwqerdelivery_3328aada85e8d88464f8dd27ce32f960'] = 'Piegāde 3h laikā';
$_MODULE['<{qwqerdelivery}prestashop>qwqerdelivery_876f23178c29dc2552c0b48bf23cd9bd'] = 'Are you sure you want to uninstall?';
$_MODULE['<{qwqerdelivery}prestashop>qwqerdelivery_0f40e8817b005044250943f57a21c5e7'] = 'No name provided';
$_MODULE['<{qwqerdelivery}prestashop>installerservice_a8475a13b5124a9a617913e8ded2890d'] = 'QWQER EXPRESS Piegāde';
$_MODULE['<{qwqerdelivery}prestashop>installerservice_3328aada85e8d88464f8dd27ce32f960'] = 'Piegāde 3h laikā';
