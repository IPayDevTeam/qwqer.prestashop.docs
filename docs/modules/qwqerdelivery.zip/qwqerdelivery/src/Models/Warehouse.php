<?php

namespace Qwqer\Delivery\Models;

use ObjectModel;
use Db;
use DbQuery;

class Warehouse extends ObjectModel
{
    public $id_qwqerdelivery_warehouse;
    public $is_default;
    public $country;
    public $countrycode2;
    public $city;
    public $citycode2;
    public $zipcode;
    public $state;
    public $statecode;
    public $region;
    public $address;

    public static $definition = [
        'table' => 'qwqerdelivery_warehouse',
        'primary' => 'id_qwqerdelivery_warehouse',
        'multilang' => false,
        'fields' => [
            'is_default' => ['type' => self::TYPE_BOOL],
            'country' => ['type' => self::TYPE_STRING],
            'countrycode2' => ['type' => self::TYPE_STRING],
            'city' => ['type' => self::TYPE_STRING],
            'citycode2' => ['type' => self::TYPE_STRING],
            'zipcode' => ['type' => self::TYPE_STRING],
            'state' => ['type' => self::TYPE_STRING],
            'statecode' => ['type' => self::TYPE_STRING],
            'region' => ['type' => self::TYPE_STRING],
            'address' => ['type' => self::TYPE_STRING],
        ]
    ];

    /**
     * @return array
     */
    public static function getCollection()
    {
        $sql = new DbQuery();
        $sql->select('*');
        $sql->from(Warehouse::$definition['table']);

        $collection = Db::getInstance()->executeS($sql);

        return ObjectModel::hydrateCollection(Warehouse::class, $collection);
    }

    /**
     * @param $id
     * @return Warehouse|null
     */
    public static function getById($id)
    {
        $sql = new DbQuery();
        $sql->select('*');
        $sql->from(Warehouse::$definition['table']);
        $sql->where(self::$definition['primary'] . ' = ' . (int)$id);

        $collection = Db::getInstance()->executeS($sql);

        if (empty($collection)) {
            return null;
        }

        return new self($collection[0]);
    }

    public static function getDefault()
    {
        $sql = new DbQuery();
        $sql->select('*');
        $sql->from(Warehouse::$definition['table']);
        $sql->where('is_default = 1');

        $collection = Db::getInstance()->executeS($sql);

        if (empty($collection)) {
            $sql = new DbQuery();
            $sql->select('*');
            $sql->from(Warehouse::$definition['table']);

            $collection = Db::getInstance()->executeS($sql);

            return new self($collection[0]['id_qwqerdelivery_warehouse']);
        }

        return new self($collection[0]['id_qwqerdelivery_warehouse']);
    }

    /**
     * @param $id
     */
    public static function removeDefaultExlcludeId($id)
    {
        $db = Db::getInstance();

        $db->update(self::$definition['table'], ['is_default' => 0], self::$definition['primary'] . ' != ' . (int)$id);
    }
}
