<?php

namespace Qwqer\Delivery\Models;

use DbQuery;
use Db;
use ObjectModel;

class CalculatedPrice extends ObjectModel
{
    public $id_qwqerdelivery_calculated_price;
    public $id_cart;
    public $id_address_delivery;
    public $id_warehouse;
    public $price;
    public $address_delivery_date;

    public static $definition = [
        'table' => 'qwqerdelivery_calculated_price',
        'primary' => 'id_qwqerdelivery_calculated_price',
        'multilang' => false,
        'fields' => [
            'id_cart' => ['type' => self::TYPE_INT],
            'id_address_delivery' => ['type' => self::TYPE_INT],
            'id_warehouse' => ['type' => self::TYPE_INT],
            'price' => ['type' => self::TYPE_INT],
            'address_delivery_date' => ['type' => self::TYPE_DATE],
        ]
    ];

    /**
     * @param int|string $cartId
     * @param int|string $deliveryAddressId
     * @param int|string $warehouseId
     * @return CalculatedPrice|null
     */
    public static function getForPriceFetch($cartId, $deliveryAddressId, $warehouseId)
    {
        $sql = new DbQuery();
        $sql->select('*');
        $sql->from(self::$definition['table']);
        $sql->where('id_cart = ' . (int)$cartId);
        $sql->where('id_address_delivery = ' . (int)$deliveryAddressId);
        $sql->where('id_warehouse = ' . (int)$warehouseId);

        $collection = Db::getInstance()->executeS($sql);

        if (empty($collection)) {
            return null;
        }

        return new self($collection[0]['id_qwqerdelivery_calculated_price']);
    }
}
