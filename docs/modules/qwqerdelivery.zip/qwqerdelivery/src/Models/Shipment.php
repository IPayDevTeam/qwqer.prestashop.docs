<?php

namespace Qwqer\Delivery\Models;

use ObjectModel;
use Db;
use DbQuery;
use Symfony\Component\VarDumper\VarDumper;

class Shipment extends ObjectModel
{
    public $id_qwqerdelivery_shipment;
    public $id_order;
    public $id_qwqer_order;
    public $status;
    public $price;
    public $payload;

    public static $definition = [
        'table' => 'qwqerdelivery_shipment',
        'primary' => 'id_qwqerdelivery_shipment',
        'multilang' => false,
        'fields' => [
            'id_order' => ['type' => self::TYPE_INT],
            'id_qwqer_order' => ['type' => self::TYPE_INT],
            'status' => ['type' => self::TYPE_STRING],
            'price' => ['type' => self::TYPE_INT],
            'payload' => ['type' => self::TYPE_STRING],
        ]
    ];

    public static function getPerPage()
    {
        return 10;
    }

    /**
     * @param array $status
     * @param int $page
     * @return array
     */
    public static function getCollection($status = null, $page = 1)
    {
        $sql = new DbQuery();
        $sql->select('SQL_CALC_FOUND_ROWS *');
        $sql->from(self::$definition['table']);

        if ($status) {
            $sql->where('status = ' . (int)$status);
        }

        $perPage = self::getPerPage();
        $sql->limit($perPage, ($page - 1) * $perPage);

        $collection = Db::getInstance()->executeS($sql);

        return ObjectModel::hydrateCollection(self::class, $collection);
    }

    /**
     * @param $id
     * @return Shipment|null
     */
    public static function getById($id)
    {
        $sql = new DbQuery();
        $sql->select('*');
        $sql->from(self::$definition['table']);
        $sql->where(self::$definition['primary'] . ' = ' . (int)$id);

        $collection = Db::getInstance()->executeS($sql);

        if (empty($collection)) {
            return null;
        }

        return new self($collection[0]);
    }

    /**
     * @param int|string $id
     * @return Shipment|null
     */
    public static function getByOrderId($id)
    {
        $sql = new DbQuery();
        $sql->select('*');
        $sql->from(self::$definition['table']);
        $sql->orderBy('id_qwqerdelivery_shipment DESC');
        $sql->where('id_order = ' . (int)$id);

        $collection = Db::getInstance()->executeS($sql);

        if (empty($collection)) {
            return null;
        }

        return new self($collection[0][self::$definition['primary']]);
    }

    /**
     * @param int $orderId
     * @param array $payload
     * @return Shipment
     */
    public static function insertNewOne($orderId, $payload)
    {
        $model = new self();
        $model->id_order = $orderId;
        $model->id_qwqer_order = $payload['id'];
        $model->status = (string)$payload['status'];
        $model->price = (int)($payload['price'] * 100);
        $model->payload = json_encode($payload);

        $model->save();

        return $model;
    }
}
