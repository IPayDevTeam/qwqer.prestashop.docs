<?php

namespace Qwqer\Delivery\Abstractions;

use ModuleAdminController;

class ControllerAbstraction extends ModuleAdminController
{
    protected function ajaxRenderJson($content)
    {
        header('Content-Type: application/json; charset=utf-8');

        die(json_encode($content, JSON_NUMERIC_CHECK));
    }
}
