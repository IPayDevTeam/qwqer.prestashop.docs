<?php

namespace Qwqer\Delivery\Helpers;

use Order;
use State;
use Address;
use Country;
use Customer;
use Currency;
use Configuration;
use Qwqer\Delivery\Models\Shipment;
use Qwqer\Delivery\Models\Warehouse;
use Qwqer\Delivery\Services\PasswordService;
use Qwqer\Delivery\Services\RequestService;
use Symfony\Component\VarDumper\VarDumper;

class OrderHelper
{
    /**
     * @param int $orderId
     * @return bool
     */
    public static function beginShipping($orderId)
    {
        $requestService = new RequestService();
        $passwordService = new PasswordService();

        $token = null;

        $order = new Order($orderId);
        $shipment = Shipment::getByOrderId($orderId);

        if ($shipment) {
            return false;
        }

        if ($order->id_carrier !== Configuration::get('QWQER_DELIVERY_CARRIER_ID')) {
            return false;
        }

        $warehouse = Warehouse::getDefault();
        $address = new Address($order->id_address_delivery);
        $country = new Country($address->id_country);
        $state = new State($address->id_state);
        $customer = new Customer($order->id_customer);
        $currency = new Currency($order->id_currency);

        if ($currency->iso_code !== 'EUR') {
            return false;
        }

        if (!$warehouse->id) {
            return false;
        }

        $parcelsTotalWeight = 0;
        foreach ($order->getProducts() as $product) {
            $parcelsTotalWeight += isset($product['product_weight']) ? $product['product_weight'] : 0;
        }

        // Login to QWQER Api
        try {
            $loginResponse = $requestService->post('/api/xr/mch/login', [
                'login' => Configuration::get('QWQER_DELIVERY_LOGIN'),
                'passw' => $passwordService->decrypt(Configuration::get('QWQER_DELIVERY_PASSWORD'))
            ]);

            $token = $loginResponse['data']['restid'];
        } catch (exception $exception) {
            return false;
        }

        // Delivery order price from QWQER Api
        try {
            $deliveryOrderPriceResponse = $requestService->post('/api/xr/mch/delivery_price', [
                'sender' => array_merge(
                    [
                        'name' => Configuration::get('PS_SHOP_NAME') ?: null,
                        'phone' => Configuration::get('PS_SHOP_PHONE') ?: null,
                        'contact' => Configuration::get('PS_SHOP_PHONE') ?: null,
                        'email' => Configuration::get('PS_SHOP_EMAIL') ?: null,
                        'company' => Configuration::get('PS_SHOP_NAME') ?: null
                    ],
                    array_filter($warehouse->getFields(), function ($value, $field) {
                        return $field !== 'id_qwqerdelivery_warehouse';
                    }, ARRAY_FILTER_USE_BOTH),
                    [
                        'address' => implode(', ', array_filter([
                            $warehouse->address,
                            $warehouse->city,
                            $warehouse->country,
                            $warehouse->state,
                            $warehouse->region,
                            $warehouse->zipcode
                        ]))
                    ]
                ),
                'receiver' => array_merge([
                    'name' => implode(' ', array_filter([$address->firstname, $address->lastname])),
                    'contact' => $address->phone ?: $address->phone_mobile,
                    'phone' => $address->phone ?: $address->phone_mobile,
                    'email' => $customer->email,
                    'company' => $address->company
                ], [
                    'country' => $address->country,
                    'countrycode2' => $country->iso_code,
                    'city' => $address->city,
                    'citycode2' => '',
                    'state' => $state->name ?: '',
                    'statecode' => $state->iso_code ?: '',
                    'region' => '',
                    'zipcode' => $address->postcode,
                    'address' => $address->address1
                ]),
                'ordersize' => [
                    'length' => 0,
                    'width' => 0,
                    'height' => 0,
                    'weight' => round($parcelsTotalWeight) ?: 1,
                    'lenunit' => 'CENTIMETER',
                    'weightunit' => 'KILOGRAM'
                ]
            ], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            return false;
        }

        $calculatedData = $deliveryOrderPriceResponse['data'];

        // Place order
        try {
            $deliveryCreateResponse = $requestService->post('/api/xr/mch/delivery', [
                'distance' => $calculatedData['distance'],
                'dunit' => 'METER',
                'dkind' => 'NONE',
                'country' => $calculatedData['sender']['countrycode2'],
                'duration' => $calculatedData['duration'],
                'summa' => $calculatedData['price'] - (isset($calculatedData['discount']) ? $calculatedData['discount'] : 0),
                'sender' => $calculatedData['sender'],
                'receiver' => $calculatedData['receiver'],
                'ordersize' => $calculatedData['ordersize'],
                'status' => 1,
            ], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            return false;
        }

        // Make payment
        try {
            $requestService->post('/api/xr/mch/delivery_payment', [
                'id' => $deliveryCreateResponse['data']['id']
            ], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            return false;
        }

        Shipment::insertNewOne($order->id, $deliveryCreateResponse['data']);

        return true;
    }
}
