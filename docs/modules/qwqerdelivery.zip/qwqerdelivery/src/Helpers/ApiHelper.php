<?php

namespace Qwqer\Delivery\Helpers;

use Cart;
use State;
use Address;
use Country;
use Customer;
use Currency;
use Configuration;
use Qwqer\Delivery\Models\Warehouse;
use Qwqer\Delivery\Models\CalculatedPrice;
use Qwqer\Delivery\Services\PasswordService;
use Qwqer\Delivery\Services\RequestService;

class ApiHelper
{
    /**
     * @param Cart $address
     * @return array|bool
     */
    public static function fetchShippingCost($cart)
    {
        $requestService = new RequestService();
        $passwordService = new PasswordService();

        $token = null;

        $warehouse = Warehouse::getDefault();
        $address = new Address($cart->id_address_delivery);
        $country = new Country($address->id_country);
        $state = new State($address->id_state);
        $customer = new Customer($cart->id_customer);
        $currency = new Currency($cart->id_currency);

        if ($currency->iso_code !== 'EUR') {
            return false;
        }

        if (!$warehouse->id) {
            return false;
        }

        $calculatedPrice = CalculatedPrice::getForPriceFetch($cart->id, $address->id, $warehouse->id);

        if (!$calculatedPrice) {
            $calculatedPrice = new CalculatedPrice();
        }

        if ($calculatedPrice->address_delivery_date === $address->date_upd) {
            if (!(int)$calculatedPrice->price) {
                return false;
            } else {
                return $calculatedPrice->price;
            }
        } else {
            $calculatedPrice->id_cart = $cart->id;
            $calculatedPrice->id_address_delivery = $address->id;
            $calculatedPrice->id_warehouse = $warehouse->id;
            $calculatedPrice->address_delivery_date = $address->date_upd;
        }

        $parcelsTotalWeight = 0;
        foreach ($cart->getProducts() as $product) {
            $parcelsTotalWeight += isset($product['product_weight']) ? $product['product_weight'] : 0;
        }

        // Login to QWQER Api
        try {
            $loginResponse = $requestService->post('/api/xr/mch/login', [
                'login' => Configuration::get('QWQER_DELIVERY_LOGIN'),
                'passw' => $passwordService->decrypt(Configuration::get('QWQER_DELIVERY_PASSWORD'))
            ]);

            $token = $loginResponse['data']['restid'];
        } catch (exception $exception) {
            return false;
        }

        // Delivery order price from QWQER Api
        try {
            $deliveryOrderPriceResponse = $requestService->post('/api/xr/mch/delivery_price', [
                'sender' => array_merge(
                    [
                        'name' => Configuration::get('PS_SHOP_NAME') ?: null,
                        'phone' => Configuration::get('PS_SHOP_PHONE') ?: null,
                        'contact' => Configuration::get('PS_SHOP_PHONE') ?: null,
                        'email' => Configuration::get('PS_SHOP_EMAIL') ?: null,
                        'company' => Configuration::get('PS_SHOP_NAME') ?: null
                    ],
                    array_filter($warehouse->getFields(), function ($value, $field) {
                        return $field !== 'id_qwqerdelivery_warehouse';
                    }, ARRAY_FILTER_USE_BOTH),
                    [
                        'address' => implode(', ', array_filter([
                            $warehouse->address,
                            $warehouse->city,
                            $warehouse->country,
                            $warehouse->state,
                            $warehouse->region,
                            $warehouse->zipcode
                        ]))
                    ]
                ),
                'receiver' => array_merge([
                    'name' => implode(' ', array_filter([$address->firstname, $address->lastname])),
                    'contact' => $address->phone ?: $address->phone_mobile,
                    'phone' => $address->phone ?: $address->phone_mobile,
                    'email' => $customer->email,
                    'company' => $address->company
                ], [
                    'country' => $address->country,
                    'countrycode2' => $country->iso_code,
                    'city' => $address->city,
                    'citycode2' => '',
                    'state' => $state->name ?: '',
                    'statecode' => $state->iso_code ?: '',
                    'region' => '',
                    'zipcode' => $address->postcode,
                    'address' => $address->address1
                ]),
                'ordersize' => [
                    'length' => 0,
                    'width' => 0,
                    'height' => 0,
                    'weight' => round($parcelsTotalWeight) ?: 1,
                    'lenunit' => 'CENTIMETER',
                    'weightunit' => 'KILOGRAM'
                ]
            ], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            return false;
        }


        if ((int)$deliveryOrderPriceResponse['data']['distance'] > 40000) {
            $deliveryOrderPriceResponse['data']['price'] = 0;
        }

        $calculatedPrice->price = ceil($deliveryOrderPriceResponse['data']['price'] * 100);
        $calculatedPrice->save();

        if ((int)$deliveryOrderPriceResponse['data']['distance'] > 40000) {
            return false;
        }

        return $calculatedPrice->price;
    }
}
