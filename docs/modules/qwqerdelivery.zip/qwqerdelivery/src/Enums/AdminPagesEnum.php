<?php

namespace Qwqer\Delivery\Enums;

class AdminPagesEnum
{
    const Main = 'AdminQwqerDeliveryMain';
    const Warehouse = 'AdminQwqerDeliveryWarehouse';
    const Shipment = 'AdminQwqerDeliveryShipment';
    const Order = 'AdminQwqerDeliveryOrder';
    const Process = 'AdminQwqerDeliveryProcess';
    const Configs = 'AdminQwqerDeliverySettings';
}
