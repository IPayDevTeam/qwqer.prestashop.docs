<?php

namespace Qwqer\Delivery\Services;

use Qwqer\Delivery\Enums\AdminPagesEnum;
use Tab;
use Language;
use Carrier;
use Zone;
use Group;
use Context;
use RangePrice;
use RangeWeight;
use Validate;
use Configuration;
use Db;

class InstallerService
{
    public $errors = [];

    protected $moduleInstance;

    private $tabs = [
        [AdminPagesEnum::Main, 'AdminParentShipping', 'QWQER Delivery'],
        [AdminPagesEnum::Warehouse, null, null],
        [AdminPagesEnum::Shipment, null, null],
        [AdminPagesEnum::Order, null, null],
        [AdminPagesEnum::Process, null, null],
        [AdminPagesEnum::Configs, null, null],
    ];

    public function __construct($_moduleInstance)
    {
        $this->moduleInstance = $_moduleInstance;
    }

    /**
     * @return bool
     */
    public function install()
    {
        $this->errors = [];

        return $this->installTabs() && $this->installDb() && $this->installCarrier();
    }

    /**
     * @return bool
     */
    public function uninstall()
    {
        $this->errors = [];

        return $this->uninstallTabs() && $this->uninstallDb() && $this->uninstallCarrier();
    }

    /**
     * @return bool
     */
    private function installTabs()
    {
        foreach ($this->tabs as list($tabToRegister, $parent, $name)) {
            $tabId = (int)Tab::getIdFromClassName($tabToRegister) ?: null;

            $tab = new Tab($tabId);
            $tab->active = 1;
            $tab->class_name = $tabToRegister;
            $tab->name = [];
            $tab->id_parent = $parent ? (int)Tab::getIdFromClassName($parent) : -1;
            $tab->module = $this->moduleInstance->name;

            foreach (Language::getLanguages(true) as $lang) {
                // $tab->name[$lang['id_lang']] = $this->trans('My Module Demo', array(), 'Modules.Qwqer.Delivery.Admin', $lang['locale']);
                $tab->name[$lang['id_lang']] = $name ?: $tabToRegister;
            }

            if (!$tab->add()) {
                return false;
            }
        }

        return true;
    }

    /**
     * @return bool
     */
    private function uninstallTabs()
    {
        foreach ($this->tabs as list($tabToRegister, $parent)) {
            $tabId = (int)Tab::getIdFromClassName($tabToRegister);

            if (!$tabId) {
                continue;
            }

            $tab = new Tab($tabId);

            if (!$tab->delete()) {
                return false;
            }
        }

        return true;
    }

    /**
     * @return bool
     */
    private function installDb()
    {
        $sql = [];

        $sql[] = "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_.$this->moduleInstance->name."_warehouse` (
            `id_".$this->moduleInstance->name."_warehouse` int(11) NOT NULL AUTO_INCREMENT,
            `is_default` TINYINT(1) DEFAULT 0,
            `country` VARCHAR(255) NOT NULL,
            `countrycode2` VARCHAR(255) NOT NULL,
            `city` VARCHAR(255) NOT NULL,
            `citycode2` VARCHAR(255) NULL,
            `zipcode` VARCHAR(255) NOT NULL,
            `state` VARCHAR(255) NULL,
            `statecode` VARCHAR(255) NULL,
            `region` VARCHAR(255) NULL,
            `address` MEDIUMTEXT NOT NULL,
            PRIMARY KEY  (`id_".$this->moduleInstance->name."_warehouse`)
        ) ENGINE="._MYSQL_ENGINE_." DEFAULT CHARSET=utf8;";

        $sql[] = "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_.$this->moduleInstance->name."_shipment` (
            `id_".$this->moduleInstance->name."_shipment` int(11) NOT NULL AUTO_INCREMENT,
            `id_order` INT(11) UNSIGNED NOT NULL,
            `id_qwqer_order` INT(11) UNSIGNED NOT NULL,
            `status` VARCHAR(255) NOT NULL,
            `price` INT(11) UNSIGNED NOT NULL,
            `payload` MEDIUMTEXT NOT NULL,
            PRIMARY KEY  (`id_".$this->moduleInstance->name."_shipment`)
        ) ENGINE="._MYSQL_ENGINE_." DEFAULT CHARSET=utf8;";

        $sql[] = "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_.$this->moduleInstance->name."_calculated_price` (
            `id_".$this->moduleInstance->name."_calculated_price` int(11) NOT NULL AUTO_INCREMENT,
            `id_cart` INT(11) UNSIGNED NOT NULL,
            `id_address_delivery` INT(11) UNSIGNED NOT NULL,
            `id_warehouse` INT(11) UNSIGNED NOT NULL,
            `price` INT(11) UNSIGNED NOT NULL,
            `address_delivery_date` DATETIME NOT NULL,
            PRIMARY KEY  (`id_".$this->moduleInstance->name."_calculated_price`)
        ) ENGINE="._MYSQL_ENGINE_." DEFAULT CHARSET=utf8;";

        foreach ($sql as $query) {
            if (!Db::getInstance()->execute($query)) {
                return false;
            }
        }

        return true;
    }

    /**
     * @return bool
     */
    private function uninstallDb()
    {
        $sql = [];

        $sql[] = "DROP TABLE IF EXISTS `"._DB_PREFIX_.$this->moduleInstance->name."_warehouse`";
        $sql[] = "DROP TABLE IF EXISTS `"._DB_PREFIX_.$this->moduleInstance->name."_shipment`";
        $sql[] = "DROP TABLE IF EXISTS `"._DB_PREFIX_.$this->moduleInstance->name."_calculated_price`";

        foreach ($sql as $query) {
            if (!Db::getInstance()->execute($query)) {
                return false;
            }
        }

        return true;
    }

    /**
     * @return bool
     */
    private function installCarrier()
    {
        $carrier = new Carrier();

        $carrier->name = $this->moduleInstance->l('QWQER Delivery');
        $carrier->is_module = true;
        $carrier->active = 1;
        $carrier->need_range = 1;
        $carrier->shipping_external = true;
        $carrier->range_behavior = 0;
        $carrier->external_module_name = $this->moduleInstance->name;
        $carrier->shipping_method = 2;

        foreach (Language::getLanguages() as $lang) {
            $carrier->delay[$lang['id_lang']] = $this->moduleInstance->l('Delivery, that doesn\'t take away your time.');
        }

        if (!$carrier->add()) {
            return false;
        }

        @copy(dirname(__FILE__).'/../../carrier-logo.jpg', _PS_SHIP_IMG_DIR_.'/'.(int)$carrier->id.'.jpg');
        Configuration::updateValue('QWQER_DELIVERY_CARRIER_ID_REFERENCE', (int)$carrier->id);
        Configuration::updateValue('QWQER_DELIVERY_CARRIER_ID', (int)$carrier->id);

        $zones = Zone::getZones();
        foreach ($zones as $zone) {
            $carrier->addZone($zone['id_zone']);
        }

        $groups_ids = [];
        $groups = Group::getGroups(Context::getContext()->language->id);
        foreach ($groups as $group) {
            $groups_ids[] = $group['id_group'];
        }
        $carrier->setGroups($groups_ids);

        $range_price = new RangePrice();
        $range_price->id_carrier = $carrier->id;
        $range_price->delimiter1 = '0';
        $range_price->delimiter2 = '10000';
        $range_price->add();

        $range_weight = new RangeWeight();
        $range_weight->id_carrier = $carrier->id;
        $range_weight->delimiter1 = '0';
        $range_weight->delimiter2 = '10000';
        $range_weight->add();

        return true;
    }

    /**
     * @return bool
     */
    private function uninstallCarrier()
    {
        $carrierId = Configuration::get('QWQER_DELIVERY_CARRIER_ID_REFERENCE');

        if (!$carrierId) {
            return true;
        }

        $carrier = Carrier::getCarrierByReference($carrierId);

        if (Validate::isLoadedObject($carrier)) {
            $carrier->delete();
            unlink(_PS_SHIP_IMG_DIR_ . '/' . (int)$carrier->id . '.jpg');
        }

        return true;
    }
}
