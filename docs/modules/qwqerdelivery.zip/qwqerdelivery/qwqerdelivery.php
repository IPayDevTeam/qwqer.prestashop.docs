<?php

use Qwqer\Delivery\Enums\AdminPagesEnum;
use Qwqer\Delivery\Helpers\ApiHelper;
use Qwqer\Delivery\Helpers\OrderHelper;
use Qwqer\Delivery\Services\InstallerService;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__.'/vendor/autoload.php';

class qwqerdelivery extends Module
{
    private $installerService;

    public function __construct()
    {
        $this->name = 'qwqerdelivery';
        $this->tab = 'shipping_logistics';
        $this->version = '0.0.6-rc';
        $this->author = 'QWQER';
        $this->need_instance = 0;

        $this->bootstrap = true;
        $this->ps_versions_compliancy = [
            'min' => '1.6',
            'max' => _PS_VERSION_
        ];

        parent::__construct();

        $this->displayName = $this->l('QWQER Delivery');
        $this->description = $this->l('Delivery, that doesn\'t take away your time.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        $this->installerService = new InstallerService($this);

        // if (!Configuration::get('MYMODULE_NAME')) {
        //     $this->warning = $this->l('No name provided');
        // }
    }

    /**
     * @return bool
     */
    public function install()
    {
        if (!parent::install()) {
            return false;
        }

        if (!$this->installerService->install()
            || !$this->registerHook('backOfficeHeader')
            || !$this->registerHook('displayAdminOrder')
            // || !$this->registerHook('actionPaymentConfirmation')
            || !$this->registerHook('actionCarrierUpdate')
        ) {
            $this->_errors = array_merge($this->_errors, $this->installerService->errors);

            return false;
        }

        return true;
    }

    /**
     * @return bool
     */
    public function uninstall()
    {
        if (!$this->installerService->uninstall()) {
            $this->_errors = array_merge($this->_errors, $this->installerService->errors);

            return false;
        }

        return parent::uninstall();
    }

    public function getContent()
    {
        Tools::redirectAdmin($this->context->link->getAdminLink(AdminPagesEnum::Main));
    }

    public function getOrderShippingCost($cart, $shipping_cost)
    {
        return $shipping_cost ? $this->getOrderShippingCostExternal($cart) : 0;
    }

    public function getOrderShippingCostExternal($cart)
    {
        if (!$this->active) {
            return false;
        }

        if (!$this->context->customer->logged || !(int)$cart->id_address_delivery) {
            return false;
        }

        // if ($cart->id_carrier !== Configuration::get('QWQER_DELIVERY_CARRIER_ID')) {
        //     return false;
        // }

        if ((bool)Configuration::get('QWQER_DELIVERY_FIXED')) {
            return (float)Configuration::get('QWQER_DELIVERY_PRICE');
        }

        $price = ApiHelper::fetchShippingCost($cart);

        if (!$price) {
            return false;
        }

        return $price / 100;
    }

    public function hookBackOfficeHeader()
    {
        $this->context->smarty->assign([
            'qwqerModule' => [
                'qwqerCarrierId' => (int)Configuration::get('QWQER_DELIVERY_CARRIER_ID'),
                'link' => [
                    'config' => $this->context->link->getAdminLink('AdminModules').'&configure=' . $this->name,
                    'warehouse' => $this->context->link->getAdminLink(AdminPagesEnum::Warehouse),
                    'shipment' => $this->context->link->getAdminLink(AdminPagesEnum::Shipment),
                    'order' => $this->context->link->getAdminLink(AdminPagesEnum::Order),
                    'process' => $this->context->link->getAdminLink(AdminPagesEnum::Process),
                    'configs' => $this->context->link->getAdminLink(AdminPagesEnum::Configs),
                    // 333 in JS will replaced by real order id
                    'orderPage' => $this->context->link->getAdminLink('AdminOrders', true, ['id_order' => 333, 'vieworder' => true])
                ]
            ]
        ]);

        $this->context->controller->addJS($this->_path.'views/js/app.min.js');
    }

    public function hookDisplayAdminOrder($params)
    {
        if (!Configuration::get('QWQER_DELIVERY_ENABLED')) {
            return null;
        }

        $order = new Order($params['id_order']);
        $params['id_carrier'] = $order->id_carrier;

        $this->context->smarty->assign($params);

        return $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'qwqerdelivery/views/templates/admin/qwqerDeliveryOrder.tpl');
    }

    public function hookActionPaymentConfirmation($params)
    {
        // OrderHelper::beginShipping($params['id_order']);
    }

    public function hookActionCarrierUpdate($params)
    {
        if ($params['carrier']->id_reference == Configuration::get('QWQER_DELIVERY_CARRIER_ID_REFERENCE')) {
            Configuration::updateValue('QWQER_DELIVERY_CARRIER_ID', $params['carrier']->id);
        }
    }
}
