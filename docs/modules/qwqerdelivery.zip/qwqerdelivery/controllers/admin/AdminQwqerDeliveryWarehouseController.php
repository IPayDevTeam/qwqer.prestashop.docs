<?php

use Qwqer\Delivery\Abstractions\ControllerAbstraction;
use Qwqer\Delivery\Models\Warehouse;

class AdminQwqerDeliveryWarehouseController extends ControllerAbstraction
{
    public function __construct()
    {
        if (!Configuration::get('QWQER_DELIVERY_ENABLED')) {
            $this->ajaxRenderJson(['error' => 'Module is disabled']);
        }

        parent::__construct();
    }

    public function ajaxProcessCollection()
    {
        $warehouses = Warehouse::getCollection();

        $this->ajaxRenderJson([
            'data' => $warehouses
        ]);
    }

    public function ajaxProcessSave()
    {
        $errors = [];

        $id = Tools::getValue('id');
        $data = Tools::getValue('data');

        if (empty($data['country'])) {
            $errors['country'] = 'Country is required';
        }
        if (empty($data['countrycode2'])) {
            $errors['countrycode2'] = 'Country ISO-2 is required';
        }
        if (empty($data['city'])) {
            $errors['city'] = 'City is required';
        }
        if (empty($data['zipcode'])) {
            $errors['zipcode'] = 'ZIP-code is required';
        }
        if (empty($data['address'])) {
            $errors['address'] = 'Address is required';
        }

        $warehouse = Warehouse::getById($id);

        if ($id && !$warehouse) {
            $errors['model'] = 'Entry does not exist';
        }

        $warehouse = new Warehouse();

        foreach ($data as $field => $value) {
            $warehouse->{$field} = $value;
        }

        if (!empty($errors)) {
            $this->ajaxRenderJson([
                'errors' => $errors
            ]);
        }

        if (isset($data['is_default']) && $data['is_default']) {
            Warehouse::removeDefaultExlcludeId($id);
        }

        $warehouse->save();

        $this->ajaxRenderJson([
            'data' => $warehouse
        ]);
    }

    public function ajaxProcessDelete()
    {
        $id = Tools::getValue('id');
        $warehouse = Warehouse::getById($id);

        if (!$warehouse) {
            $this->ajaxRenderJson([
                'error' => 'Entry does not exist'
            ]);
        }

        $warehouse = new Warehouse($id);
        $warehouse->delete();

        $this->ajaxRenderJson(['data' => true]);
    }
}
