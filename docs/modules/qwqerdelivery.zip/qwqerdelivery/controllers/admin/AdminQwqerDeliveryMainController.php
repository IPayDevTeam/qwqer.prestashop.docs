<?php

use Qwqer\Delivery\Abstractions\ControllerAbstraction;

class AdminQwqerDeliveryMainController extends ControllerAbstraction
{
    public function __construct()
    {
        $this->bootstrap = true;

        parent::__construct();
    }

    public function initContent()
    {
        parent::initContent();

        $template = $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'qwqerdelivery/views/templates/admin/qwqerDeliveryMain.tpl');

        $this->context->smarty->assign([
            'content' => $template
        ]);
    }
}
