<?php

use Qwqer\Delivery\Abstractions\ControllerAbstraction;

class AdminQwqerDeliveryOrderController extends ControllerAbstraction
{
    public function __construct()
    {
        if (!Configuration::get('QWQER_DELIVERY_ENABLED')) {
            $this->ajaxRenderJson(['error' => 'Module is disabled']);
        }

        parent::__construct();
    }

    public function ajaxProcessGet()
    {
        $order = new Order(Tools::getValue('id'));
        if (!$order->id) {
            $this->ajaxRenderJson(['error' => 'Order does not exist']);
        }

        $customer = new Customer($order->id_customer);
        if (!$customer->id) {
            $this->ajaxRenderJson(['error' => 'Order customer does not exist']);
        }

        $address = new Address($order->id_address_delivery);
        if (!$address->id) {
            $this->ajaxRenderJson(['error' => 'Order address does not exist']);
        }

        $country = new Country($address->id_country);
        if (!$country->id) {
            $this->ajaxRenderJson(['error' => 'Address country does not exist']);
        }

        $state = new State($address->id_state);
        if (!$state->id) {
            $state = null;
        }

        $this->ajaxRenderJson([
            'data' => compact('order', 'customer', 'address', 'country', 'state')
        ]);
    }
}
