<?php

use Qwqer\Delivery\Abstractions\ControllerAbstraction;
use Qwqer\Delivery\Models\Shipment;

use Order;
use Qwqer\Delivery\Services\PasswordService;
use Qwqer\Delivery\Services\RequestService;

class AdminQwqerDeliveryShipmentController extends ControllerAbstraction
{
    protected $requestService;
    protected $passwordService;

    public function __construct()
    {
        if (!Configuration::get('QWQER_DELIVERY_ENABLED')) {
            $this->ajaxRenderJson(['error' => 'Module is disabled']);
        }

        $this->requestService = new RequestService();
        $this->passwordService = new PasswordService();

        parent::__construct();
    }

    public function ajaxProcessList()
    {
        $filter = Tools::getValue('filter') ?: [];
        $page = (int)Tools::getValue('page') ?: 1;

        $warehouses = Shipment::getCollection(isset($filter['status']) ? $filter['status'] : null, $page);

        $perPage = Shipment::getPerPage();
        $total = Db::getInstance()->executeS('SELECT FOUND_ROWS();');
        $total = $total[0]['FOUND_ROWS()'];

        foreach ($warehouses as &$warehouse) {
            $warehouse->order = new Order($warehouse->id_order);
        }

        $this->ajaxRenderJson([
            'data' => $warehouses,
            'meta' => [
                'current_page' => $page,
                'from' => (($page - 1) * $perPage) + 1,
                'last_page' => ceil($total / $perPage),
                'per_page' => $perPage,
                'to' => (($page - 1) * $perPage) + $perPage,
                'total' => $total
            ]
        ]);
    }

    public function ajaxProcessUpdateStatus()
    {
        $id = (int)Tools::getValue('id');

        $shipment = new Shipment($id);
        $token = null;

        if (!$shipment->id) {
            $this->ajaxRenderJson(['error' => 'Shipment does not exist']);
        }

        // Login to QWQER Api
        try {
            $loginResponse = $this->requestService->post('/api/xr/mch/login', [
                'login' => Configuration::get('QWQER_DELIVERY_LOGIN'),
                'passw' => $this->passwordService->decrypt(Configuration::get('QWQER_DELIVERY_PASSWORD'))
            ]);

            $token = $loginResponse['data']['restid'];
        } catch (exception $exception) {
            $this->ajaxRenderJson(['error' => $exception->getMessage()]);
        }

        // Fetch order from QWQER API
        try {
            $orderDataResponse = $this->requestService->get('/api/xr/mch/delivery/' . $shipment->id_qwqer_order, [], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            $this->ajaxRenderJson(['error' => $exception->getMessage()]);
        }

        $shipment->status = $orderDataResponse['data']['status'];
        $shipment->save();

        $this->ajaxRenderJson([
            'data' => $shipment
        ]);
    }

    public function ajaxProcessRejectOrder()
    {
        $id = (int)Tools::getValue('id');

        $shipment = new Shipment($id);
        $token = null;

        if (!$shipment->id) {
            $this->ajaxRenderJson(['error' => 'Shipment does not exist']);
        }

        // Login to QWQER Api
        try {
            $loginResponse = $this->requestService->post('/api/xr/mch/login', [
                'login' => Configuration::get('QWQER_DELIVERY_LOGIN'),
                'passw' => $this->passwordService->decrypt(Configuration::get('QWQER_DELIVERY_PASSWORD'))
            ]);

            $token = $loginResponse['data']['restid'];
        } catch (exception $exception) {
            $this->ajaxRenderJson(['error' => $exception->getMessage()]);
        }

        // Reject order by QWQER API
        try {
            $this->requestService->delete('/api/v1/carorder/' . $shipment->id_qwqer_order, [], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            $this->ajaxRenderJson(['error' => $exception->getMessage()]);
        }

        $this->ajaxRenderJson([
            'data' => true
        ]);
    }

    public function ajaxProcessGetShipmentByOrderId()
    {
        $id = (int)Tools::getValue('id');
        $shipment = Shipment::getByOrderId($id);

        $this->ajaxRenderJson([
            'data' => $shipment
        ]);
    }
}
