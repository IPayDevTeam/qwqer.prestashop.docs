<?php

use Qwqer\Delivery\Abstractions\ControllerAbstraction;
use Qwqer\Delivery\Models\Shipment;
use Qwqer\Delivery\Models\Warehouse;
use Qwqer\Delivery\Services\PasswordService;
use Qwqer\Delivery\Services\RequestService;

class AdminQwqerDeliveryProcessController extends ControllerAbstraction
{
    protected $requestService;
    protected $passwordService;

    public function __construct()
    {
        if (!Configuration::get('QWQER_DELIVERY_ENABLED')) {
            $this->ajaxRenderJson(['error' => 'Module is disabled']);
        }

        $this->requestService = new RequestService();
        $this->passwordService = new PasswordService();

        parent::__construct();
    }

    public function ajaxProcessGetPrice()
    {
        $validationErrors = [];

        $orderId = Tools::getValue('orderId');
        $warehouseId = Tools::getValue('warehouseId');
        $data = Tools::getValue('data');
        $token = Tools::getValue('authToken');

        if (empty($data['country'])) {
            $validationErrors['country'] = 'Country is required';
        }
        if (empty($data['countrycode2'])) {
            $validationErrors['countrycode2'] = 'Country ISO-2 is required';
        }
        if (empty($data['city'])) {
            $validationErrors['city'] = 'City is required';
        }
        if (empty($data['zipcode'])) {
            $validationErrors['zipcode'] = 'ZIP-code is required';
        }
        if (empty($data['address'])) {
            $validationErrors['address'] = 'Address is required';
        }

        if (!empty($validationErrors)) {
            $this->ajaxRenderJson(['errors' => $validationErrors]);
        }

        $order = new Order($orderId);
        if (!$order->id) {
            $this->ajaxRenderJson(['error' => 'Order does not exist']);
        }

        $customer = new Customer($order->id_customer);
        if (!$customer->id) {
            $this->ajaxRenderJson(['error' => 'Order customer does not exist']);
        }

        $address = new Address($order->id_address_delivery);
        if (!$address->id) {
            $this->ajaxRenderJson(['error' => 'Order address does not exist']);
        }

        $warehouse = new Warehouse($warehouseId);
        if (!$warehouse->id) {
            $this->ajaxRenderJson(['error' => 'Warehouse does not exist']);
        }

        $parcelsTotalWeight = 0;
        foreach ($order->getProducts() as $product) {
            $parcelsTotalWeight += isset($product['product_weight']) ? $product['product_weight'] : 0;
        }

        // Login to QWQER Api
        if (!$token) {
            try {
                $loginResponse = $this->requestService->post('/api/xr/mch/login', [
                    'login' => Configuration::get('QWQER_DELIVERY_LOGIN'),
                    'passw' => $this->passwordService->decrypt(Configuration::get('QWQER_DELIVERY_PASSWORD'))
                ]);

                $token = $loginResponse['data']['restid'];
            } catch (exception $exception) {
                $this->ajaxRenderJson(['error' => $exception->getMessage()]);
            }
        }

        // Delivery order price from QWQER Api
        try {
            $deliveryOrderPriceResponse = $this->requestService->post('/api/xr/mch/delivery_price', [
                'sender' => array_merge(
                    [
                        'name' => Configuration::get('PS_SHOP_NAME') ?: null,
                        'phone' => Configuration::get('PS_SHOP_PHONE') ?: null,
                        'contact' => Configuration::get('PS_SHOP_PHONE') ?: null,
                        'email' => Configuration::get('PS_SHOP_EMAIL') ?: null,
                        'company' => Configuration::get('PS_SHOP_NAME') ?: null
                    ],
                    array_filter($warehouse->getFields(), function ($value, $field) {
                        return $field !== 'id_qwqerdelivery_warehouse';
                    }, ARRAY_FILTER_USE_BOTH),
                    [
                        'address' => implode(', ', array_filter([
                            $warehouse->address,
                            $warehouse->city,
                            $warehouse->country,
                            $warehouse->state,
                            $warehouse->region,
                            $warehouse->zipcode
                        ]))
                    ]
                ),
                'receiver' => array_merge([
                    'name' => implode(' ', array_filter([$address->firstname, $address->lastname])),
                    'contact' => $address->phone ?: $address->phone_mobile,
                    'phone' => $address->phone ?: $address->phone_mobile,
                    'email' => $customer->email,
                    'company' => $address->company
                ], $data),
                'ordersize' => [
                    'length' => 0,
                    'width' => 0,
                    'height' => 0,
                    'weight' => round($parcelsTotalWeight) ?: 1,
                    'lenunit' => 'CENTIMETER',
                    'weightunit' => 'KILOGRAM'
                ]
            ], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            $this->ajaxRenderJson(['error' => $exception->getMessage()]);
        }

        if ((int)$deliveryOrderPriceResponse['data']['distance'] > 40000) {
            $this->ajaxRenderJson(['error' => 'Distance is more than 40km from pick up point']);
        }

        $this->ajaxRenderJson([
            'data' => [
                'token' => $token,
                'response' => $deliveryOrderPriceResponse['data'],
                'price' => (float)$deliveryOrderPriceResponse['data']['price']
            ]
        ]);
    }

    public function ajaxProcessPlaceOrder()
    {
        $order = new Order(Tools::getValue('orderId'));

        if (!$order->id) {
            $this->ajaxRenderJson(['error' => 'Order does not exist']);
        }

        $calculatedData = Tools::getValue('calculatedData');
        $token = Tools::getValue('authToken');

        // Login to QWQER Api
        if (!$token) {
            try {
                $loginResponse = $this->requestService->post('/api/xr/mch/login', [
                    'login' => Configuration::get('QWQER_DELIVERY_LOGIN'),
                    'passw' => $this->passwordService->decrypt(Configuration::get('QWQER_DELIVERY_PASSWORD'))
                ]);

                $token = $loginResponse['data']['restid'];
            } catch (exception $exception) {
                $this->ajaxRenderJson(['error' => $exception->getMessage()]);
            }
        }

        // Place order
        try {
            $deliveryCreateResponse = $this->requestService->post('/api/xr/mch/delivery', [
                'distance' => $calculatedData['distance'],
                'dunit' => 'METER',
                'dkind' => 'NONE',
                'country' => $calculatedData['sender']['countrycode2'],
                'duration' => $calculatedData['duration'],
                'summa' => $calculatedData['price'] - (isset($calculatedData['discount']) ? $calculatedData['discount'] : 0),
                'sender' => $calculatedData['sender'],
                'receiver' => $calculatedData['receiver'],
                'ordersize' => $calculatedData['ordersize'],
                'status' => 1,
            ], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            $this->ajaxRenderJson(['error' => $exception->getMessage()]);
        }

        // Make payment
        try {
            $this->requestService->post('/api/xr/mch/delivery_payment', [
                'id' => $deliveryCreateResponse['data']['id']
            ], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            $this->ajaxRenderJson(['error' => $exception->getMessage()]);
        }

        Shipment::insertNewOne($order->id, $deliveryCreateResponse['data']);

        $this->ajaxRenderJson(['data' => true]);
    }
}
