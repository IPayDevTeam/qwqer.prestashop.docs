<?php

use Qwqer\Delivery\Abstractions\ControllerAbstraction;

use Qwqer\Delivery\Services\PasswordService;
use Qwqer\Delivery\Services\RequestService;

class AdminQwqerDeliverySettingsController extends ControllerAbstraction
{
    protected $requestService;
    protected $passwordService;

    public function __construct()
    {
        $this->requestService = new RequestService();
        $this->passwordService = new PasswordService();

        parent::__construct();
    }

    public function ajaxProcessEnabled()
    {
        $this->ajaxRenderJson(['data' => (bool)Configuration::get('QWQER_DELIVERY_ENABLED')]);
    }

    public function ajaxProcessGet()
    {
        $this->ajaxRenderJson([
            'data' => [
                'enabled' => (bool)Configuration::get('QWQER_DELIVERY_ENABLED'),
                'login' => Configuration::get('QWQER_DELIVERY_LOGIN') ?: null,
                'password' => Configuration::get('QWQER_DELIVERY_PASSWORD') ? true : false,
                'fixed' => (bool)Configuration::get('QWQER_DELIVERY_FIXED'),
                'price' => (float)(Configuration::get('QWQER_DELIVERY_PRICE') ?: 0.01),
            ]
        ]);
    }

    public function ajaxProcessUpdate()
    {
        $errors = [];

        $post = [
            'enabled' => (bool)Tools::getValue('enabled'),
            'login' => trim(Tools::getValue('login')),
            'password' => trim(Tools::getValue('password')),
            'fixed' => trim(Tools::getValue('fixed')),
            'price' => trim(Tools::getValue('price')),
        ];

        $currentPassword = Configuration::get('QWQER_DELIVERY_PASSWORD') ?: null;

        if (!$post['login']) {
            $errors['login'] = 'Login is required';
        } else if (strlen($post['login']) < 4) {
            $errors['login'] = 'Login must have not least than 4 symbols';
        }

        if (!$currentPassword && !$post['password']) {
            $errors['password'] = 'Password is required';
        } else if ($post['password'] && strlen($post['password']) < 6) {
            $errors['password'] = 'Password must have not least than 6 symbols';
        }

        if ($post['fixed']) {
            if ((float)$post['price'] < 0.01) {
                $errors['price'] = 'Price is less than 0.01';
            }
        }

        if (!empty($errors)) {
            $this->ajaxRenderJson(['errors' => $errors]);
        }

        if (Configuration::get('QWQER_DELIVERY_LOGIN') !== $post['login'] || $post['password']) {
            try {
                $this->requestService->post('/api/xr/mch/login', [
                    'login' => $post['login'],
                    'passw' => isset($post['password']) && $post['password'] ? $post['password'] : $this->passwordService->decrypt(Configuration::get('QWQER_DELIVERY_PASSWORD'))
                ]);
            } catch (exception $exception) {
                $this->ajaxRenderJson(['error' => $exception->getMessage()]);
            }
        }

        Configuration::updateValue('QWQER_DELIVERY_ENABLED', $post['enabled']);
        Configuration::updateValue('QWQER_DELIVERY_LOGIN', $post['login']);

        Configuration::updateValue('QWQER_DELIVERY_FIXED', $post['fixed']);
        Configuration::updateValue('QWQER_DELIVERY_PRICE', $post['price']);

        if ($post['password']) {
            Configuration::updateValue('QWQER_DELIVERY_PASSWORD', $this->passwordService->encrypt($post['password']));
        }

        $this->ajaxProcessEnabled();
    }
}
